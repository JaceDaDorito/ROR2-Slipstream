#Slipstream
Slipstream is an in-the-works content mod that aims to vary your Risk of Rain 2 runs with build defining items, brand-new enemy encounters, and breath taking locales. We hope to make Petrichor V a wild ride to explore!

Currently, we don't have stages or many items but we are working hard to try and add some soon. Contact (JaceDaDorito#7035) on Discord if there is any issues, most of the devs here are extremely new to modding so be patient.

##Credits
*Code - JaceDaDorito, Atlantean/Dot/Org, Zach, MoonlitWyvern
*Experienced Code/Unity Support - Nebby, swuff, Twiner (Thank you for doing what you do, you guys are great and without your expertise, Lost In Transit, Rain of Stages, and Thunderkit this mod wouldn't exist)
*2D Artists - Kamei, Runefield, JaceDaDorito, Vaikyia, Dodu, splet, Hans, KoopaHunter197
*Modelers/3D Artists - Kamei, foodrelatedname, dotflare
*Writing - LordBidoof, splet, JaceDaDorito
*Special Thanks - TheTimesweeper, PlasmaCore, Alexis, Ochus, Lompl, Schmizz, Hyperin, Knowledge, Spacecats, SilverSinz

Go play Lost In Transit btw good mod.